﻿namespace Traffic.Constants
{
    public enum VehicleType
    {
        Bike,
        TukTuk,
        Car
    }
}
