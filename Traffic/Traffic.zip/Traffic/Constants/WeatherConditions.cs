﻿namespace Traffic.Constants
{
    public class WeatherConditions
    {
        public const string SUNNY = "SUNNY";
        public const string WINDY = "WINDY";
        public const string RAINY = "RAINY";
    }
}
