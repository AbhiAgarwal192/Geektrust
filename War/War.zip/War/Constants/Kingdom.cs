﻿using System.Diagnostics.CodeAnalysis;

namespace War.Constants
{
    [ExcludeFromCodeCoverage]
    public class Kingdom
    {
        public const string LENGABURU = "LENGABURU";
        public const string FALICORNIA = "FALICORNIA";
    }
}
