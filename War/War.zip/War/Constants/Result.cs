﻿using System.Diagnostics.CodeAnalysis;

namespace War.Constants
{
    [ExcludeFromCodeCoverage]
    public class Result
    {
        public const string WINS = "WINS";
        public const string LOSES = "LOSES";
    }
}
